# Sakin Portfolio App

Flutter portfolio app with Facebook/TikTok links and a password-gated dashboard containing portfolio, marketing, graphics, and AI-assistant screens.

## Optional images

Put these files in `assets/images/` to customize the home screen:
- `profile1.webp` — profile portrait
- `profile2.webp` — banner image
- `logo.png` — brand logo

If an image is missing, the app displays a neutral icon fallback rather than crashing.

## Build APK

Requires Flutter SDK, Android SDK, and Java 17.

```bash
flutter pub get
flutter analyze
flutter build apk --release
```

The release APK should be generated at:
`build/app/outputs/flutter-apk/app-release.apk`

### Build from a phone using GitHub Actions

1. Upload this project to a GitHub repository (include the `.github` folder).
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and tap **Run workflow** (or push to `main`/`master`).
4. When the workflow completes successfully, open the run and download the `sakin-portfolio-release-apk` artifact.

The workflow regenerates Flutter's Android platform files, installs dependencies, runs `flutter analyze`, and only then attempts the release APK build. A successful build has not been verified in this workspace.

## Security note

The current secret-area password check is embedded in the Dart client code. It is suitable only as a casual hidden screen, not as real security; secrets embedded in an app can be extracted. Do not use this gate to protect sensitive data. For real access control, use server-side authentication. If the password in the original README was real, change it before distributing the app.
