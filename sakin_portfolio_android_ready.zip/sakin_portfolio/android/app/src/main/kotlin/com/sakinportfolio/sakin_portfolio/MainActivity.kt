package com.sakinportfolio.sakin_portfolio

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
