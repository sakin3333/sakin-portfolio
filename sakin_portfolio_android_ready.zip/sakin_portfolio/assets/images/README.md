Optional image assets. Add your own files with these exact names to replace the built-in fallbacks:
- profile1.webp (profile portrait)
- profile2.webp (top banner)
- logo.png (brand logo)
The app now displays icon-based fallbacks when any of these files are missing.
