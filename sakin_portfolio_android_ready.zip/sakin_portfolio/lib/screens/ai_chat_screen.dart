import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AiChatScreen extends StatefulWidget {
  const AiChatScreen({super.key});

  @override
  State<AiChatScreen> createState() => _AiChatScreenState();
}

class _AiChatScreenState extends State<AiChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final List<Map<String, String>> messages = [];

  void _sendMessage() {
    final text = _controller.text.trim();
    if (text.isEmpty) return;

    setState(() {
      messages.add({'role': 'user', 'text': text});
      messages.add({
        'role': 'ai',
        'text': _generateReply(text),
      });
    });
    _controller.clear();
  }

  String _generateReply(String input) {
    final lower = input.toLowerCase();
    if (lower.contains('hashtag') || lower.contains('হ্যাশট্যাগ')) {
      return 'এই টপিকের জন্য কিছু হ্যাশট্যাগ:\n#DigitalMarketing #ContentCreator #GrowYourBusiness #SocialMediaTips #MarketingStrategy';
    } else if (lower.contains('caption') || lower.contains('ক্যাপশন')) {
      return 'একটা ভালো ক্যাপশন:\n"সফলতা রাতারাতি আসে না। প্রতিদিন একটু একটু করে এগিয়ে যাও।"\n\n#Motivation #Success';
    } else if (lower.contains('color') || lower.contains('রঙ')) {
      return 'প্রফেশনাল কালার প্যালেট:\nPrimary: #0A0A0A\nAccent: #00B4D8\nLight: #90E0EF';
    } else {
      return 'আমি শুধু মার্কেটিং ও গ্রাফিক্স ডিজাইন নিয়ে সাহায্য করতে পারি।\n\nতুমি বলতে পারো:\n- হ্যাশট্যাগ চাই\n- ক্যাপশন চাই\n- কালার প্যালেট চাই\n- ফন্ট সাজেশন চাই';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: Text('AI Assistant', style: GoogleFonts.poppins()),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final msg = messages[index];
                final isUser = msg['role'] == 'user';
                return Align(
                  alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(12),
                    constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                    decoration: BoxDecoration(
                      color: isUser ? const Color(0xFF00B4D8) : const Color(0xFF1A1A2E),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Text(msg['text']!, style: GoogleFonts.poppins(fontSize: 14)),
                  ),
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.all(12),
            color: const Color(0xFF1A1A2E),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(
                      hintText: 'মেসেজ লিখো...',
                      hintStyle: TextStyle(color: Colors.white38),
                      border: InputBorder.none,
                    ),
                    onSubmitted: (_) => _sendMessage(),
                  ),
                ),
                IconButton(
                  onPressed: _sendMessage,
                  icon: const Icon(Icons.send, color: Color(0xFF00B4D8)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
