import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

class GraphicsTools extends StatefulWidget {
  const GraphicsTools({super.key});

  @override
  State<GraphicsTools> createState() => _GraphicsToolsState();
}

class _GraphicsToolsState extends State<GraphicsTools> {
  String result = '';

  final List<List<Color>> palettes = [
    [Color(0xFF0A0A0A), Color(0xFF00B4D8), Color(0xFF90E0EF), Color(0xFFCAF0F8)],
    [Color(0xFF1A1A2E), Color(0xFFE94560), Color(0xFF0F3460), Color(0xFF16213E)],
    [Color(0xFF2D132C), Color(0xFF801336), Color(0xFFC72C41), Color(0xFFEE4540)],
    [Color(0xFF0B0C10), Color(0xFF1F2833), Color(0xFFC5C6C7), Color(0xFF66FCF1)],
  ];

  void _generatePalette() {
    final random = palettes[DateTime.now().millisecond % palettes.length];
    setState(() {
      result = 'Color Palette:\n\n'
          'Primary: #${random[0].value.toRadixString(16).substring(2).toUpperCase()}\n'
          'Secondary: #${random[1].value.toRadixString(16).substring(2).toUpperCase()}\n'
          'Accent: #${random[2].value.toRadixString(16).substring(2).toUpperCase()}\n'
          'Light: #${random[3].value.toRadixString(16).substring(2).toUpperCase()}';
    });
  }

  void _generateFonts() {
    setState(() {
      result = 'Recommended Font Pairing:\n\n'
          'Heading: Poppins Bold\n'
          'Subheading: Poppins SemiBold\n'
          'Body: Inter Regular\n'
          'Accent: Montserrat Medium';
    });
  }

  void _copy() {
    Clipboard.setData(ClipboardData(text: result));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('কপি হয়েছে!')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: Text('Graphics Tools', style: GoogleFonts.poppins()),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            ElevatedButton(
              onPressed: _generatePalette,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF00B4D8),
                minimumSize: const Size(double.infinity, 50),
              ),
              child: const Text('Generate Color Palette'),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: _generateFonts,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF00B4D8),
                minimumSize: const Size(double.infinity, 50),
              ),
              child: const Text('Font Pairing Suggestion'),
            ),
            const SizedBox(height: 24),
            if (result.isNotEmpty)
              Expanded(
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1A1A2E),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: SelectableText(result, style: GoogleFonts.poppins(fontSize: 15)),
                ),
              ),
            if (result.isNotEmpty) ...[
              const SizedBox(height: 12),
              ElevatedButton.icon(
                onPressed: _copy,
                icon: const Icon(Icons.copy),
                label: const Text('কপি করো'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF00B4D8),
                  minimumSize: const Size(double.infinity, 48),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
