import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:google_fonts/google_fonts.dart';
import '../widgets/password_dialog.dart';
import 'secret_screen.dart';

Widget _profileImageFallback(BuildContext context, Object error, StackTrace? stackTrace) {
  return const Center(
    child: Icon(Icons.person_outline, size: 64, color: Color(0xFF00B4D8)),
  );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Future<void> _launchUrl(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('লিংক খোলা যায়নি')),
      );
    }
  }

  void _onProfileLongPress() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => PasswordDialog(
        correctPassword: 'Sakin.@#1234567891010',
        onSuccess: () {
          Navigator.pop(context);
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const SecretScreen()),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF0A0A0A), Color(0xFF111827)],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              children: [
                // Banner
                Container(
                  height: 220,
                  width: double.infinity,
                  clipBehavior: Clip.antiAlias,
                  decoration: const BoxDecoration(
                    color: Color(0xFF172033),
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(30),
                      bottomRight: Radius.circular(30),
                    ),
                  ),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.asset(
                        'assets/images/profile2.webp',
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) => const Center(
                          child: Icon(Icons.image_outlined, size: 64, color: Colors.white38),
                        ),
                      ),
                      DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [Colors.transparent, Colors.black54],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // Profile Picture (Long Press)
                Transform.translate(
                  offset: const Offset(0, -60),
                  child: GestureDetector(
                    onLongPress: _onProfileLongPress,
                    child: Container(
                      padding: const EdgeInsets.all(5),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: const Color(0xFF00B4D8), width: 3),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF00B4D8).withOpacity(0.4),
                            blurRadius: 20,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: CircleAvatar(
                        radius: 65,
                        backgroundColor: Color(0xFF172033),
                        child: ClipOval(
                          child: SizedBox.expand(
                            child: Image.asset(
                              'assets/images/profile1.webp',
                              fit: BoxFit.cover,
                              errorBuilder: _profileImageFallback,
                            ),
                          ),
                        ),
                      ),
                    ).animate().scale(duration: 600.ms, curve: Curves.easeOutBack),
                  ),
                ),

                // Logo
                Image.asset(
                  'assets/images/logo.png',
                  height: 50,
                  errorBuilder: (context, error, stackTrace) => const Icon(
                    Icons.auto_awesome,
                    size: 42,
                    color: Color(0xFF00B4D8),
                  ),
                ).animate().fadeIn(delay: 200.ms),

                const SizedBox(height: 12),

                // Name & Bio
                Text(
                  'Sakin',
                  style: GoogleFonts.poppins(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ).animate().fadeIn(delay: 300.ms),

                const SizedBox(height: 6),

                Text(
                  'Digital Marketer & Graphic Designer',
                  style: GoogleFonts.poppins(
                    fontSize: 14,
                    color: Colors.white70,
                  ),
                ).animate().fadeIn(delay: 400.ms),

                const SizedBox(height: 8),

                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFF00B4D8).withOpacity(0.15),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    '📍 Bangladesh',
                    style: GoogleFonts.poppins(fontSize: 12, color: const Color(0xFF00B4D8)),
                  ),
                ).animate().fadeIn(delay: 500.ms),

                const SizedBox(height: 40),

                // Buttons
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 30),
                  child: Column(
                    children: [
                      _buildButton(
                        title: 'Follow on Facebook',
                        icon: Icons.facebook,
                        color: const Color(0xFF1877F2),
                        onTap: () => _launchUrl('https://www.facebook.com/share/1C9CHeR41G/'),
                      ).animate().slideX(begin: -0.2, delay: 600.ms),

                      const SizedBox(height: 16),

                      _buildButton(
                        title: 'Watch TikTok Videos',
                        icon: Icons.music_note,
                        color: const Color(0xFF000000),
                        borderColor: Colors.white24,
                        onTap: () => _launchUrl('https://www.tiktok.com/@sakin.714'),
                      ).animate().slideX(begin: 0.2, delay: 700.ms),
                    ],
                  ),
                ),

                const SizedBox(height: 50),

                Text(
                  'Long press on profile picture for secret access',
                  style: GoogleFonts.poppins(fontSize: 11, color: Colors.white24),
                ),
                const SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildButton({
    required String title,
    required IconData icon,
    required Color color,
    Color? borderColor,
    required VoidCallback onTap,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: borderColor != null ? BorderSide(color: borderColor) : BorderSide.none,
          ),
          elevation: 8,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 22),
            const SizedBox(width: 12),
            Text(
              title,
              style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
    );
  }
}
