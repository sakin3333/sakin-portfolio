import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

class MarketingTools extends StatefulWidget {
  const MarketingTools({super.key});

  @override
  State<MarketingTools> createState() => _MarketingToolsState();
}

class _MarketingToolsState extends State<MarketingTools> {
  final TextEditingController _keywordController = TextEditingController();
  String result = '';

  void _generateHashtags() {
    final keyword = _keywordController.text.trim();
    if (keyword.isEmpty) return;
    setState(() {
      result = '#$keyword #${keyword}Marketing #Digital${keyword} #GrowWith$keyword #${keyword}Tips #SocialMedia #ContentCreator #BusinessGrowth #OnlineMarketing #Success';
    });
  }

  void _generateCaption() {
    final keyword = _keywordController.text.trim();
    if (keyword.isEmpty) return;
    setState(() {
      result = 'আজকের দিনে $keyword নিয়ে কাজ করা মানেই সফলতার দিকে একধাপ এগিয়ে যাওয়া।\n\nনিয়মিত কন্টেন্ট দাও, ধৈর্য রাখো, আর নিজেকে বিশ্বাস করো।\n\n#${keyword} #Motivation #DigitalMarketing';
    });
  }

  void _generateUTM() {
    final keyword = _keywordController.text.trim();
    if (keyword.isEmpty) return;
    setState(() {
      result = 'https://yourwebsite.com/?utm_source=facebook&utm_medium=social&utm_campaign=$keyword&utm_content=post1';
    });
  }

  void _copy() {
    Clipboard.setData(ClipboardData(text: result));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('কপি হয়েছে!')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: Text('Marketing Tools', style: GoogleFonts.poppins()),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: _keywordController,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Keyword লিখো (যেমন: fashion)',
                hintStyle: const TextStyle(color: Colors.white38),
                filled: true,
                fillColor: const Color(0xFF1A1A2E),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                _btn('Hashtags', _generateHashtags),
                _btn('Caption', _generateCaption),
                _btn('UTM Link', _generateUTM),
              ],
            ),
            const SizedBox(height: 24),
            if (result.isNotEmpty)
              Expanded(
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1A1A2E),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: SingleChildScrollView(
                    child: SelectableText(result, style: GoogleFonts.poppins(fontSize: 14)),
                  ),
                ),
              ),
            if (result.isNotEmpty) ...[
              const SizedBox(height: 12),
              ElevatedButton.icon(
                onPressed: _copy,
                icon: const Icon(Icons.copy),
                label: const Text('কপি করো'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF00B4D8),
                  minimumSize: const Size(double.infinity, 48),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _btn(String text, VoidCallback onTap) {
    return ElevatedButton(
      onPressed: onTap,
      style: ElevatedButton.styleFrom(
        backgroundColor: const Color(0xFF00B4D8),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
      child: Text(text),
    );
  }
}
