import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class PortfolioScreen extends StatelessWidget {
  const PortfolioScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: Text('My Portfolio', style: GoogleFonts.poppins()),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _item('Project 1 - Brand Identity', 'Graphics Design'),
          _item('Project 2 - Social Media Campaign', 'Digital Marketing'),
          _item('Project 3 - Logo Design', 'Branding'),
          _item('Project 4 - Content Strategy', 'Marketing'),
          const SizedBox(height: 20),
          Text(
            'এখানে তুমি নিজের প্রজেক্টের লিংক বা ছবি যোগ করতে পারবে।',
            style: GoogleFonts.poppins(color: Colors.white54, fontSize: 13),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _item(String title, String subtitle) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A2E),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: const Color(0xFF00B4D8).withOpacity(0.15),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.folder_open, color: Color(0xFF00B4D8)),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
                Text(subtitle, style: GoogleFonts.poppins(fontSize: 12, color: Colors.white54)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
